package Org.S2;

import java.util.Scanner;

class Product
{
	private int P_id,Price;
	private String name;
	public void setId(int P_id)
	{
		this.P_id=P_id;
	}
	public int getId()
	{
		return P_id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public void setPrice(int Price)
	{
		this.Price=Price;
	}
	public int getPrice()
	{
		return Price;
	}
}
class Sh
{    
	Product p1[];
	void acceptProduct(Product p1[])
	{
		this.p1=p1;
	}
	void show()
	{
		System.out.println("Product details with");
		System.out.println("Product_id  name   Price");
		for(int i=0;i<p1.length;i++)
		{
			System.out.println(p1[i].getId()+"\t"+p1[i].getName()+"\t"+p1[i].getPrice());
		}
	}
	void Search()
	{
		System.out.println("Enter product_id for search");
		Scanner xyz=new Scanner(System.in);
		int Ps=xyz.nextInt();
		for(int i=0;i<p1.length;i++)
		{
			if(p1[i].getId()==Ps)
			{
				System.out.println("Product details are");
				System.out.println(+p1[i].getId()+"\t"+p1[i].getName()+"\t"+p1[i].getPrice());
			}
		}
		
	}
}

public class PrdctS2App {

	public static void main(String[] args) {
		Product p1[]=new Product[5];
		for(int i=0;i<p1.length;i++)
		{
			p1[i]=new Product();
			Scanner xyz=new Scanner(System.in);
			System.out.println("Enter Product_id, Product name and Product price");
			int P_id=xyz.nextInt();
			String name=xyz.next();
			int Price=xyz.nextInt();
			p1[i].setId(P_id);
			p1[i].setName(name);
			p1[i].setPrice(Price);	
		}
		Sh p2=new Sh();
		p2.acceptProduct(p1);
		p2.show();	
		p2.Search();
    
	}

}
