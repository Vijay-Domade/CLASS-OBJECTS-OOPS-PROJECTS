package org.s2;

import java.util.Scanner;

class Player
{
	private int Pl_id,Run;
	private String name;
	public void setId(int Pl_id)
	{
		this.Pl_id=Pl_id;
	}
	public int getId()
	{
		return Pl_id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public void setRun(int Run)
	{
		this.Run=Run;
	}
	public int getRun()
	{
		return Run;
	}
	public void show()
	{
		System.out.println("ID="+Pl_id+" Run="+Run+" name= "+name);

	}
}
class Team
{
	Player pl[];
	int pl1;
	void setPlayers(Player pl[])
	{
		this.pl=pl;
	}
	void showPlayers()
	{

		System.out.println("Players details with");
		System.out.println("Player_id  name   Run");
		for(int i=0;i<pl.length;i++)
		{
			System.out.println(pl[i].getId()+"\t"+pl[i].getName()+"\t"+pl[i].getRun());
		}
	
	}
	Player getplayer(int pl1)
	{
		this.pl1=pl1;
		boolean b=false;
		int k=0;
		for(int i=0;i<pl.length;i++)
		{
			if(pl[i].getId()==pl1)
			{
				k=i;
				b=true;
			}
		}
		if(b)
		{
			return pl[k];
		}
		else
		{
			return null;
		}
	}
	
}

public class PlayerS2Ap {

	public static void main(String[] args) {
		Player pl[]=new Player[5];
		for(int i=0;i<pl.length;i++)
		{
			pl[i]=new Player();
			Scanner xyz=new Scanner(System.in);
			System.out.println("Enter Player_id, Player name and Player Run");
			int Pl_id=xyz.nextInt();
			String name=xyz.next();
			int Run=xyz.nextInt();
			pl[i].setId(Pl_id);
			pl[i].setName(name);
			pl[i].setRun(Run);	
		}
		Team t=new Team();
		t.setPlayers(pl);
		t.showPlayers();
		System.out.println("Enter player_id for search");
		Scanner xyz=new Scanner(System.in);
		int pl1_id=xyz.nextInt();
		Player temp;
		temp=t.getplayer(pl1_id);
		  if(temp!=null)
		  {
			  temp.show();
			 System.out.println("Record found");
		  }
		  else
		  {
			  System.out.println("Record not found");
		  }
		
		
	}

}
