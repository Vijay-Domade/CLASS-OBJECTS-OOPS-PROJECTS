package Org.s2;
import java.util.Scanner;
class book
{

	private int f_id;
	private String name,author;
	public void setId(int f_id)
	{
		this.f_id=f_id;
	}
	public int getId()
	{
		return f_id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public void setAuthor(String author)
	{
		this.author=author;
	}
	public String getAuthor()
	{
		return author;
	}
	public void show()
	{
		System.out.println("FIELD_ID="+f_id+"Name="+name+"Author= "+author);

	}
	
}
class Library
{
	book bk[];
	String au;
	void setbook(book bk[])
	{
		this.bk=bk;
	}
	void showbooks()
	{

		System.out.println("Book details with");
		System.out.println("Field_id  Book_name   Book_author");
		for(int i=0;i<bk.length;i++)
		{
			System.out.println(bk[i].getId()+"\t"+bk[i].getName()+"\t"+bk[i].getAuthor());
		}
	
	}
	book getBook(String au)
	{
		this.au=au;
		boolean b=false;
		int k=0;
		for(int i=0;i<bk.length;i++)
		{
			if(bk[i].getAuthor().equals(au))
			{
				k=i;
				b=true;
			}
		}
		if(b)
		{
			return bk[k];
		}
		else
		{
			return null;
		}
	}
	
}

public class BookS2 {

	public static void main(String[] args) {
		book bk[]=new book[2];
		for(int i=0;i<bk.length;i++)
		{
			bk[i]=new book();
			Scanner xyz=new Scanner(System.in);
			System.out.println("Enter Book field_id, Book name and Book author");
			int f_id=xyz.nextInt();
			String name=xyz.next();
			String author=xyz.next();
			bk[i].setId(f_id);
			bk[i].setName(name);
			bk[i].setAuthor(author);	
		}
		Library t=new Library();
		t.setbook(bk);
		t.showbooks();
		System.out.println("Enter author name for search");
		Scanner xyz=new Scanner(System.in);
	    String au=xyz.next();
		book m;
		m=t.getBook(au);
		  if(m!=null)
		  {
			  System.out.println("Record found");
			  m.show();
		
		  }
		  else
		  {
			  System.out.println("Record not found");
		  }
		

	}

}
