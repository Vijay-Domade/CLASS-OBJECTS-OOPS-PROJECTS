package Org.S1;
import java.util.Scanner;
class Employee
{
	private int id,sal;
	private String name;
	public void setId(int id)
	{
		this.id=id;
	}
	public int getId()
	{
		return id;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public void setSal(int sal)
	{
		this.sal=sal;
	}
	public int getSal()
	{
		return sal;
	}
}
class Sh
{    
	Employee e1[];
	void acceptEmp(Employee e1[])
	{
		this.e1=e1;
	}
	void show()
	{
		System.out.println("Employee details with Employee id,name and salary");
		for(int i=0;i<e1.length;i++)
		{
			System.out.println(e1[i].getId()+"\t"+e1[i].getName()+"\t"+e1[i].getSal());
		}
	}
}

public class EmpS1 {

	public static void main(String[] args) {
		Employee e1[]=new Employee[5];
		for(int i=0;i<e1.length;i++)
		{
			e1[i]=new Employee();
			Scanner xyz=new Scanner(System.in);
			System.out.println("Enter Employee_id,name and salary");
			int Emp_id=xyz.nextInt();
			String name=xyz.next();
			int sal=xyz.nextInt();
			e1[i].setId(Emp_id);
			e1[i].setName(name);
			e1[i].setSal(sal);	
		}
		Sh s=new Sh();
		s.acceptEmp(e1);
		s.show();
	}

}
